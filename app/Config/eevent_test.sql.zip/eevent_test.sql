-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 13. Mrz 2013 um 01:02
-- Server Version: 5.5.29
-- PHP-Version: 5.4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `eevent_test`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(455) NOT NULL,
  `news_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_id1_idx` (`news_id`),
  KEY `comments_id2_idx` (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `comments`
--

INSERT INTO `comments` (`id`, `content`, `news_id`, `users_id`, `isdisabled`, `created`, `modified`) VALUES
(3, 'hthraj arhgegrfdx ydfxzdfjd sdhf ad', 2, 2, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `forums`
--

CREATE TABLE `forums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `description` varchar(200) NOT NULL,
  `users_id` int(11) NOT NULL,
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forums_id1_idx` (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `forums`
--

INSERT INTO `forums` (`id`, `name`, `description`, `users_id`, `isdisabled`, `created`, `modified`) VALUES
(1, 'adsfadsf', 'asdfasdf asdf asdf asd fadf', 1, 0, NULL, NULL),
(2, 'fffffffffff fffffff ffffff f ', 'hhhhhhh  hh hgh hh h', 2, 0, NULL, NULL),
(3, 'Dies ist ein Richtiger Thread mit wichtigem titel.', 'awoidub alisjf awldfk lakwrr law rrflj awrlj fawewel ljawefe ljawf ljawef law jw', 3, 0, NULL, NULL),
(4, 'Dies ist ein Richtiger Thread mit wichtigem titel.', 'awoidub alisjf awldfk lakwrr law rrflj awrlj fawewel ljawefe ljawf ljawef law jw', 3, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `users_id` int(11) NOT NULL,
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_id1_idx` (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `users_id`, `isdisabled`, `created`, `modified`) VALUES
(2, 'Testnews', 'This is content', 1, 0, '2013-02-08 01:23:26', '2013-02-08 01:23:26'),
(3, 'sadvaydfvyxfvxfv', 'ycxvyxcvyxcvyxcvyxcxcv yxc vyxcv yxcv yxcvyxcvy cvyxcvyxcvyxcv', 2, 0, '2013-02-08 01:23:39', '2013-02-08 01:23:39'),
(6, 'Sitzplan Defragmentierung 1.0', 'In 51 Tagen geht in Worb die Post ab! Dies merken wir bereits jetzt beim Sitzplan.<br /> <br /> Die Nachfrage, nebeneinander sitzen zu k&ouml;nnen, steigt enorm. Freie Pl&auml;tze sind nur noch rar anzutreffen.<br /> Aus diesen Gr&uuml;nden wurde das Vormerken der Sitzpl&auml;tze per sofort eingestellt!<br /> <br /> Die bereits vorgemerkten Pl&auml;tze werden am kommenden Wochenende definitiv freigegeben. Bis dahin k&ouml;nnen sie weiterhin von bezahlten Teilnehmern ohne weiteres &uuml;bersteuert werden.<br /> <br /> Euch bleiben folglich noch zwei Tage &uuml;brig, die Zahlungen zu t&auml;tigen. Wer auf Nummer sicher gehen will, kann uns auch die <strong>Zahlungsbest&auml;tigung (mit UID, Nickname, Vorname und Nachname)</strong> via E-Mail (info@erenya.ch) zukommen lassen.<br /> <br /> Wir entschuldigen uns f&uuml;r diese radikalen Massnahmen, welche leider unabdingbar sind.<br /> <br /> In einem zweiten Defragmentierungsschritt werden die Sitzpl&auml;tze pro Reihe so geschoben, dass einzelne Pl&auml;tze wegfallen.', 1, 1, NULL, NULL),
(7, 'Erenya Catering Aktion', '<p>Ab sofort k&ouml;nnt ihr den <strong>Buffalo classic Energy Drink</strong> f&uuml;r die Erenya-LAN #8 <a target="_self" href="/catering/"><strong>vorbestellen</strong></a>. Wir nehmen euch das m&uuml;hsame Schleppen ab, stellen euch das Getr&auml;kt kalt und bieten zudem einzigartige Preise an!<br /> <br /> &nbsp;Die Pakete von 6, 12 oder 24 Buffalo classic Energy Drinks zu <strong>1.- CHF pro Dose</strong>, bringen euch folgende Vorteile:</p> <ul>     <li>Die Buffalo classic Energy Drinks liegen beim LAN-Party Start bei uns im K&uuml;hlraum bereit.</li>     <li>Mittels einem Bon-System k&ouml;nnt ihr <strong>jederzeit eure gek&uuml;hlten Buffalo classic Energy Drinks</strong> <strong>abholen</strong> kommen.*</li>     <li>Die vorbestellten Buffalo classic Energy Drinks werden direkt beim Check-In der Erenya-LAN #8 Bar bezahlt.</li> </ul> <br /> An dieser Stelle m&ouml;chten wir euch den Buffalo classic Energy Drink etwas n&auml;her vorstellen:<br />', 2, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(600) NOT NULL,
  `users_id` int(11) NOT NULL,
  `threads_id` int(11) NOT NULL,
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_id_idx` (`users_id`),
  KEY `posts_id1_idx` (`threads_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 COMMENT='	' AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `posts`
--

INSERT INTO `posts` (`id`, `content`, `users_id`, `threads_id`, `isdisabled`, `created`, `modified`) VALUES
(1, 'yvcyxcvyxcvyxcvyxcvyxcv', 1, 2, 0, NULL, NULL),
(2, 'xxxxxaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 2, 2, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `threads`
--

CREATE TABLE `threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `forums_id` int(11) NOT NULL,
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `threads_id1_idx` (`users_id`),
  KEY `threads_id2_idx` (`forums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 COMMENT='				' AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `threads`
--

INSERT INTO `threads` (`id`, `title`, `type`, `users_id`, `forums_id`, `isdisabled`, `created`, `modified`) VALUES
(1, 'sgfddddddddddddddddddddd', NULL, 1, 1, 0, NULL, NULL),
(2, 'gsreeeeeeeeeeeeeeeeeeeeeeeeeee', NULL, 2, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `prename` varchar(45) NOT NULL,
  `surname` varchar(45) NOT NULL,
  `birthdate` datetime NOT NULL,
  `clan` varchar(45) DEFAULT NULL,
  `website` varchar(45) DEFAULT NULL,
  `status` int(5) NOT NULL DEFAULT '0',
  `isdisabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=armscii8 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `prename`, `surname`, `birthdate`, `clan`, `website`, `status`, `isdisabled`, `created`, `modified`) VALUES
(1, 'doss', '1234', '', 'Dominique', 'Hostettler', '2013-02-08 00:17:00', 'mYinsanity', 'www.test.com', 0, 0, '2013-02-08 00:17:58', '2013-02-11 00:34:38'),
(2, 'Schloc', '1234', '', 'Cedric', 'Schlosser', '1993-02-08 00:19:00', 'mYinsanity', 'testdaw', 0, 0, '2013-02-08 00:19:48', '2013-02-08 00:19:48'),
(3, 'test', '81dc9bdb52d04dc20036dbd8313ed055', '', '', '', '0000-00-00 00:00:00', NULL, NULL, 0, 0, '2013-02-10 23:36:19', '2013-02-10 23:36:19'),
(4, '', '', '', '', '', '0000-00-00 00:00:00', NULL, NULL, 0, 0, '2013-02-10 23:36:29', '2013-02-10 23:36:29'),
(5, 'andi', 'ce0e5bf55e4f71749eade7a8b95c4e46', '', 'Andi', 'megert', '2013-03-06 23:06:51', NULL, NULL, 0, 0, NULL, NULL);

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_id1` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_id2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `forums`
--
ALTER TABLE `forums`
  ADD CONSTRAINT `forums_id1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_id1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_id` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_id1` FOREIGN KEY (`threads_id`) REFERENCES `threads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `threads`
--
ALTER TABLE `threads`
  ADD CONSTRAINT `threads_id1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `threads_id2` FOREIGN KEY (`forums_id`) REFERENCES `forums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
